请解压整个压缩包，保持 document.md 与 assets/ 的相对位置。数学、脚注和合并表格需要 research Markdown 兼容阅读器。
