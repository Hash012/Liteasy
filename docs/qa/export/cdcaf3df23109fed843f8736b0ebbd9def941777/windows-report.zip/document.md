# 合成 Windows 报告


这是一份本机导出测试，不是真实论文。















| 列 A | 列 B |
| --- | --- |
| 中文 | WINDOWS_TABLE_TAIL |



$$
\frac{a}{b}+\sqrt{x}
$$


![方向图](assets/1a93f27061dd04296678d393690610c5c4b10d35d596bc3b5523207ff517ef9c.jpg)


WINDOWS_SOURCE_LAST_PARAGRAPH
